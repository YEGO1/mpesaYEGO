/* This is a generated file, edit the .stub.php file instead.
 * Stub hash: 7dac6edd98e3e17669ae4bf0be7db89678059ca0 */

ZEND_BEGIN_ARG_WITH_RETURN_TYPE_INFO_EX(arginfo_dl, 0, 1, _IS_BOOL, 0)
	ZEND_ARG_TYPE_INFO(0, extension_filename, IS_STRING, 0)
ZEND_END_ARG_INFO()
